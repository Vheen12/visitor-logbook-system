<?php
session_start();    
    require_once "config.php";

    // fetch ID pass from different sessions
    $id = $_GET['id'];
    
    if($_SESSION["page"] === "account"){
        // Prepare Sql Statement
        $sql = "DELETE FROM admin_accounts WHERE adminID = $id";

        if(mysqli_query($con,$sql)){
            mysqli_close($con);
            header('location: ../pages/accountsPage.php');
            exit;
        }else{
            echo "Error Deleting Record";
        }
    }

    if($_SESSION["page"] === "department"){
        // Prepare Sql Statement
        $sql = "DELETE FROM department WHERE deptID = $id";

        if(mysqli_query($con,$sql)){
            mysqli_close($con);
            header('location: ../pages/department.php');
            exit;
        }else{
            echo "Error Deleting Record";
        }
    }

    if($_SESSION["page"] === "transaction"){
        // Prepare Sql Statement
        $sql = "DELETE FROM visiting_details WHERE ID = $id";

        if(mysqli_query($con,$sql)){
            mysqli_close($con);
            header('location: ../pages/transaction.php');
            exit;
        }else{
            echo "Error Deleting Record";
        }
    }

    if($_SESSION["page"] == "profile"){

        // Prepare Sql Statement
        $sql = "DELETE FROM visitor_information WHERE ID = $id";

        if(mysqli_query($con,$sql)){
            mysqli_close($con);
            header('location: ../pages/profiles.php');
            exit;
        }else{
            echo "Error Deleting Record";
        }
    }
?>