<?php
    // Initialize the session
    session_start();

    // Fetch ID
    $id = $_GET['id'];

    // Check if the user is logged in, if not then redirect him to login page
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("location: ../auth/login.php");
        exit;
    }

    // Include config file
    require_once "../auth/config.php";
    
    // Trap ID if null
    // if(empty($id)){

    // }
    $sql = "SELECT * FROM visitor_information WHERE ID = '$id'";
    if($query = mysqli_query($con,$sql)){
        if($res = mysqli_num_rows($query)>0){
          $data = mysqli_fetch_assoc($query);
        }
    }
    // Fill Office dropdown
    $sql_dept = "SELECT * FROM department";
    if($query = mysqli_query($con,$sql_dept)){
        if($res = mysqli_num_rows($query)>0){
          $dept_opt = mysqli_fetch_all($query);
        }
    }

    $purpose = $dept_name = "";
    // Retrieve data from html form
    if($_SERVER["REQUEST_METHOD"] == "POST"){

        // $login = $_POST['id'];
    
        $sql = "SELECT * FROM visitor_information WHERE ID = '$id'";
    
        if($query = mysqli_query($con,$sql)){
            if($res = mysqli_num_rows($query)>0){
              $store = mysqli_fetch_assoc($query);
              $purpose = $_REQUEST['purpose'];
                $dept_name = $_REQUEST['dept'];

                $dept_sql = "SELECT * FROM department where deptID = $dept_name";
                if($query = mysqli_query($con,$dept_sql)){
                    if(mysqli_num_rows($query) > 0){
                        $result_dept = mysqli_fetch_assoc($query);
                    }
                }
                $dept_new = $result_dept['deptName'];
                $visit_ID = $store['visitor_name'];
                $sql2 = "INSERT INTO visiting_details(visitor_ID, purpose,dept)values('$visit_ID','$purpose','$dept_new')";
                
                if($result = mysqli_query($con,$sql2)){
                    echo "<script>alert('User Login')</script>";
                    header('location: userLog.php');
                }
                else{
                  echo "<script>alert('User Not Registered')</script>";
                }
            }
        }else{
            $err = "ID is not Registered";
        }
        // Close connection
        mysqli_close($con);
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <title>Quezon Visita</title>
    <link rel="shortcut icon" href="../../assets/images/lgu-quezon.png" />
</head>

<body>
    <div class="container pt-5" style="width: 40rem;">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <img style="height:120px;" src="../../assets/images/lgu-quezon.png">                    
                </div>
                <h2 class="card-title text-center mb-3">Visitor Logbook Details</h2>
                <!-- <p class="card-description">Input Visitor Data for Registration.</p> -->
                <form method="post" class="forms-sample">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="lName">Name</label>
                                <input type="text" readonly
                                    class="form-control"
                                    name="lastname" id="lName" value="<?php echo $data['visitor_name']; ?>">
                            </div>
                        </div>
                    </div>
                    <!-- Address Field -->
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="municipality">Address</label>
                                <input type="text" name="municipal" class="form-control" readonly value="<?php echo $data['homeAddress']; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="contact">Contact Number</label>
                                <input type="tel" value="<?php echo $data['contact']; ?>" name="contact" maxlength="11" class="form-control" id="contact" disabled>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" disabled name="email" value="<?php echo $data['email']; ?>" class="form-control" id="email">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="vaxStat">Vaccine Status</label>
                                <input type="email" disabled name="email" value="<?php echo $data['vaccineStat']; ?>" class="form-control" id="vaxStat">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="purpose">Purpose</label>
                                <select name="purpose" id="purpose" class="form-select">
                                    <option value="visit">Visit</option>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="dept">Department</label>
                                <select name="dept" id="purpose" class="form-select">
                                    <option value="0">--Select--</option>
                                    <?php
                                      foreach ($dept_opt as $option) {
                                        echo "<option value='$option[0]'>$option[1]</option>";
                                      }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- Buttons -->
                    <button type="submit" value="submit" class="btn btn-primary me-2 mt-3">Save</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>