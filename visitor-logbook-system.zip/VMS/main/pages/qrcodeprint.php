<?php
    // Initialize the session
    session_start();

    // Retrieve ID
    $id = $_GET['id'];

    // Include config file
    include "../auth/config.php";

    // Define variables and initialize with empty values
    $name = "gg";
    $contact = "";
    $homeaddress = "";

    $sql = "SELECT * FROM visitor_information WHERE ID = '$id'";

    if($query = mysqli_query($con,$sql)){
        if($res = mysqli_num_rows($query)>0){
            $data = mysqli_fetch_assoc($query);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Generator</title>
    <link rel="stylesheet" href="../../css/style.css">

    <!-- Inject Javascript -->
    <script type="text/javascript" src="../../js/jquery.min.js"></script>
	<script type="text/javascript" src="../../js/qrcode.js"></script>
	<script type="text/javascript" src="../../js/html2canvas.js"></script>
</head>
<body>
    <div class="container-scroller">
        <div class="container-fluid page-body-wrapper full-page-wrapper">
            <div class="content-wrapper d-flex align-items-center auth">
                <div class="row flex-grow" >
                    <h1 class="text-center mb-5 text-primary">QR Code Preview</h1>
                    <div class="col-lg-5 mx-auto">
                        <div class="auth-form-light text-left p-5">
                            <div class="row">
                                <div class="col-7">
                                    <p class="fs-4 text-start text-dark fw-bold"> <?php echo $data['visitor_name'];?> </p>
                                    <p class="fs-6 text-dark"> <?php echo $data['contact'];?> </p>
                                    <p class="fs-6 text-dark"> <?php echo $data['homeAddress'];?> </p>
                                </div>
                                <div class="col-5">
                                    <div id="qrcode"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center mt-5">
                        <button id="btn-save" type="button" class="btn btn-primary">Download QR Code</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- inject custom javascript -->
    <script type="text/javascript">
        var qrcode = new QRCode("qrcode",{
            text: "<?php echo $data['visitor_ID'] ;?>",
            width: 180,
            height: 180
        });

        $("#btn-save").on('click', function(){
            html2canvas(document.getElementById("qrcode")).then(function(canvas){
                var anchorTag =document.createElement("a");
                document.body.appendChild(anchorTag);
                // document.getElementById("previewimg").appendChild(canvas);
                anchorTag.download = "<?php echo $data['visitor_name'];?>.png";
                anchorTag.href = canvas.toDataURL();
                anchorTag.target = '_blank';
                anchorTag.click();
            })
        });
    </script>

     <!-- <script>
        $("#btn-save").on('click', function(){
            html2canvas(document.getElementById("qrcode")).then(function(canvas){
                var anchorTag =document.createElement("a");
                document.body.appendChild(anchorTag);
                // document.getElementById("previewimg").appendChild(canvas);
                anchorTag.download = "<?php echo $data['visitor_name'];?>.png";
                anchorTag.href = canvas.toDataURL();
                anchorTag.target = '_blank';
                anchorTag.click();
            })
        });
    </script> -->
</body>
</html>  