 <?php
// Initialize the session
session_start();

$_SESSION["page"] = "account";
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
  header("location: ../auth/login.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Administrator Accounts</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../css/flag-icon.min.css">
    <link rel="stylesheet" href="../../css/vendor.bundle.base.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <!-- endinject -->
    <!-- plugin: datatables css -->
    <link rel="stylesheet" href="../../datatables/css/dataTables.bootstrap5.css">
    <link rel="stylesheet" href="../../datatables/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="../../datatables/css/responsive.dataTables.css">
    <link rel="stylesheet" href="../../datatables/css/responsive.dataTables.min.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/lgu-quezon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo mt-5" href="../index.php"><img src="../../assets/images/lgu.svg" alt="logo" style="height:120px; margin-top:30px;" /></a>
          <a class="navbar-brand brand-logo-mini" href="../index.php"><img src="../../assets/images/mini-lgu.svg" alt="logo" /></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>

      <!-- This is the Sidebar -->
      <div class="container-fluid page-body-wrapper">
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav mt-5">
            <li class="nav-item nav-category">Main</li>
            <li class="nav-item">
              <a class="nav-link" href="../index.php">
                <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="profiles.php">
                <span class="icon-bg"><i class="mdi mdi-account-multiple menu-icon"></i></span>
                <span class="menu-title">Profiles</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="admins.php">
                <span class="icon-bg"><i class="mdi mdi-account-circle menu-icon"></i></span>
                <span class="menu-title">User Accounts</span>
              </a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="transaction.php">
              <span class="icon-bg"><i class="mdi mdi-file-document-box menu-icon"></i></span>
              <span class="menu-title">Visitor Transactions</span>
            </a>
          </li>
            <li class="nav-item">
              <a class="nav-link" href="department.php">
                <span class="icon-bg"><i class="mdi mdi-home-modern menu-icon"></i></span>
                <span class="menu-title">Departments</span>
              </a>
            </li>
              <li class="nav-item sidebar-user-actions">
              <div class="user-details">
                <div class="d-flex justify-content-between align-items-center">
                  <div>
                    <div class="d-flex align-items-center">
                      <div class="sidebar-profile-text">
                        <p class="mb-1"><b class=" font-weight-bold text-success">Current User</b><b class="ms-3"><?php echo htmlspecialchars($_SESSION["adminUsername"]); ?></b></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <li class="nav-item sidebar-user-actions">
              <div class="sidebar-user-menu">
                <a href="../auth/reset-password.php" class="nav-link"><i class="mdi mdi-key-change menu-icon"></i>
                  <span class="menu-title">Change Password</span></a>
              </div>
            </li>
            <li class="nav-item sidebar-user-actions">
              <div class="sidebar-user-menu">
                <a href="../auth/logout.php" class="nav-link"><i class="mdi mdi-logout menu-icon"></i>
                  <span class="menu-title">Log Out</span></a>
              </div>
            </li>
          </ul>
        </nav>

        <!-- This is the main panel -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">Administrator Accounts</h3>
              <nav aria-label="breadcrumb">
                <button type="button" onclick="" class="btn btn-primary btn-icon-text">
                  <i class="mdi mdi-account-plus btn-icon-prepend"></i> Add
                </button>
              </nav>
            </div>
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body table-responsive">
                  <table id="datatable" class="table table-bordered table-striped">
                    <thead class="table-dark">
                      <tr>
                        <th> # </th>
                        <th> Username </th>
                        <th> Password </th>
                        <th> Date Created </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        require_once "../auth/config.php";
                        $sql = "SELECT * FROM admin_accounts";
                        if ($result = mysqli_query($con, $sql)) {
                          if (mysqli_num_rows($result) > 0) {
                            $sn = 1;
                            while ($records = mysqli_fetch_array($result)) {
                        ?>
                      <tr>
                        <td> <?php echo $sn; ?></td>
                        <td> <?php echo $records[1]; ?></td>
                        <td> <?php echo $records[2]; ?></td>
                        <td> <?php echo $records[3]; ?></td>
                      </tr>
                      <?php $sn++;
                    }
                  }
                }?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
          <!-- content-wrapper ends -->
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="../../js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../js/off-canvas.js"></script>
    <script src="../../js/hoverable-collapse.js"></script>
    <script src="../../js/misc.js"></script>

    <!-- plugins: datatables js -->
    <script src="../../datatables/js/jquery.dataTables.min.js"></script>
    <script src="../../datatables/js/jquery.dataTables.js"></script>
    <script src="../../datatables/js/dataTables.bootstrap5.js"></script>
    <script src="../../datatables/js/dataTables.bootstrap5.min.js"></script>
    <script src="../../datatables/js/dataTables.responsive.min.js"></script>
    <script src="../../datatables/js/dataTables.responsive.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script>
      $(document).ready(function() {
        $('#datatable').DataTable({
          responsive: true
        });
      });
    </script>
    <!-- End custom js for this page -->
  </body>
</html>