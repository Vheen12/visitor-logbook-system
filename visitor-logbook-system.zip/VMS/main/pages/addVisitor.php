<?php
  // Initialize the session
  session_start();

  // Check if the user is logged in, if not then redirect him to login page
  if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../auth/login.php");
    exit;
  }

  // Include config file
  require_once "../auth/config.php";

  // Fill dropdownlist for municipality
  $query_municipality = mysqli_query($con, "SELECT * FROM municipal_address");
  if($query_municipality){
    if (mysqli_num_rows($query_municipality) > 0) {
      $municipal_opt = mysqli_fetch_all($query_municipality);
    }
  }

  // Fill dropdownlist for barangay
  $query_brgy = mysqli_query($con, "SELECT * FROM brgy_address");
  if ($query_brgy) {
    if (mysqli_num_rows($query_brgy) > 0) {
      $brgy_opt = mysqli_fetch_all($query_brgy);
    }
  }

  // Fill dropdownlist for purok
  $query_street = mysqli_query($con, "SELECT * FROM purok_address");
  if ($query_street) {
    if (mysqli_num_rows($query_street) > 0) {
      $street_opt = mysqli_fetch_all($query_street);
    }
  }

  // Fill dropdown for vaccine status
  $query_vaxStat = "SELECT * FROM vaccine_stat";
  if($res = mysqli_query($con,$query_vaxStat)){
    if(mysqli_num_rows($res) > 0){
      $vaccine = mysqli_fetch_all($res);
    }
  }

  if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Retrieve data from html form
    $lastname = $_REQUEST['lastname'];
    $firstname = $_REQUEST['firstname'];
    $midname = $_REQUEST['midname'];
    $extname = $_REQUEST['extname'];
    $fullname = "";
    $birthdate = $_REQUEST['birthdate'];

    // Check for Empty Fields
    if (empty(trim($firstname))) {
      $error_prompt = "Please fill empty fields";
    }
    elseif (empty(trim($lastname))) {
      $error_prompt = "Please fill empty fields";
    }
    elseif (empty(trim($midname))) {
      $error_prompt = "Please fill empty fields";
    }
    // Check if invalid input
    elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $lastname) && !preg_match('/^[a-zA-Z0-9_]+$/', $firstname)
    && !preg_match('/^[a-zA-Z0-9_]+$/', $midname) && !preg_match('/^[a-zA-Z0-9_]+$/', $extname)) {
      $error_prompt = "You can only contain letters, numbers, and underscores.";
    }
    else {
      // Fetch data from the database
      $fullname = $lastname . ", " . $firstname . ", " . $midname.", ".$extname;
      $sql = "SELECT ID FROM visitor_information WHERE visitor_name = '$fullname'";

      // store result
      $result = mysqli_query($con, $sql);

      // Check duplicate record
      if (mysqli_num_rows($result) == 1) {
        $error_prompt = "Name has already been registered";
        $fullname = "";
      }
    }

    // Check if there is no error
    if (empty($error_prompt)) {
      // Get age from Birthdate
      $dateToday = date('Y-m-d');
      $date = new DateTime($birthdate);
      $bdate = $date->format('Y-m-d,');
      $format = date_diff(date_create($bdate), date_create($dateToday));
            
      // Get value of address
      $street = $_REQUEST['street'];
      $barangay = $_REQUEST['brgy'];
      $municipality = $_REQUEST['municipal'];
      $province = "ISABELA";

      $sql_brgy = "SELECT * FROM brgy_address WHERE brgyID = $barangay";
      if($result = mysqli_query($con,$sql_brgy)){
        $res_brgy = mysqli_fetch_assoc($result);
        $brgy_new = $res_brgy["barangay"];
      }

      $sql_purok = "SELECT * FROM purok_address WHERE purokID = $street";
      if($result = mysqli_query($con,$sql_purok)){
        $res_purok = mysqli_fetch_assoc($result);
        $purok = $res_purok["purok"];
      }
      
      // Get and store value of Vaccine Status
      $vaxStat = $_REQUEST['vaccination'];

      $sql_vaccine = "SELECT * FROM vaccine_stat WHERE ID = $vaxStat";
      if($result= mysqli_query($con,$sql_vaccine)){
        $res_vaccine = mysqli_fetch_assoc($result);
        $vax_status = $res_vaccine["vax_stat"];
      }

      // Prepare parameters
      $fullname = strtoupper($fullname);
      $full_address = $purok.", ".$brgy_new.", ".$municipality.", ".$province;
      $age = $format->format('%y');
      $birthdate = $_REQUEST['birthdate'];
      $visitorID = $_REQUEST['visitorID'];
      $email = $_REQUEST['email'];
      $contact = $_REQUEST['contact'];
      $gender = $_REQUEST['gender'];
      $vaccine_stat = $vax_status;

      // Insert Data to database
      $sql = "INSERT INTO visitor_information(visitor_ID,visitor_name,birthdate,age,gender,homeAddress,contact,email,vaccineStat) values('$visitorID','$fullname','$birthdate','$age','$gender','$full_address','$contact','$email','$vaccine_stat')";

      if (mysqli_query($con, $sql)) {
        echo '<script> alert("Registered")</script>';
      }
    }
  }
  mysqli_close($con);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <title>Visitor Logbook System</title>
    <link rel="shortcut icon" href="../../assets/images/lgu-quezon.png" />
</head>

<body>
    <div class="container pt-5" style="width: 40rem;">
        <div class="card mt-5">
            <div class="card-body">
                <div class="text-center">
                    <img style="height:120px;" src="../../assets/images/lgu-quezon.png">                    
                </div>
                <h2 class="card-title text-center mt-3 mb-3">Visitor Information</h2>
                <p class="card-description">Input Visitor Data for Registration.</p>
                <?php
                    if (!empty($error_prompt)) {
                      echo '<div class="alert alert-danger">' . $error_prompt . '</div>';
                    }
                ?>
                <form method="post" class="forms-sample">
                    <div class="row">
                        <div clas="col">
                            <div class="form-group">
                                <input type="text" value="<?php echo uniqid(); ?>" hidden
                                    class="form-control <?php echo(!empty($error_prompt)) ? 'is-invalid' : ''; ?>"
                                    name="visitorID" id="visitorID">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="lName">Last Name</label>
                                <input type="text" autofocus
                                    class="form-control <?php echo(!empty($error_prompt)) ? 'is-invalid' : ''; ?>"
                                    name="lastname" id="lName">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="fName">First Name</label>
                                <input type="text"
                                    class="form-control <?php echo(!empty($error_prompt)) ? 'is-invalid' : ''; ?>"
                                    name="firstname" id="fName">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="mName">Middle Name</label>
                                <input type="text"
                                    class="form-control <?php echo(!empty($error_prompt)) ? 'is-invalid' : ''; ?>"
                                    name="midname" id="mName">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="extName">Extension</label>
                                <input type="text"
                                    class="form-control <?php echo(!empty($syntax_err)) ? 'is-invalid' : ''; ?>"
                                    name="extname" id="extName">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="birthdate">Date of Birth</label>
                                <input type="date" name="birthdate" class="form-control" id="birthdate">
                            </div>
                        </div>
                        <div class="col">
                                <div class="form-group">
                                    <label for="gender">Gender</label>
                                    <select name="gender" id="gender" class="form-select">
                                        <option value="0"></option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                        </div>
                    </div>
                    <!-- Address Field -->
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="street">Street/Purok</label>
                                <select name="street" id="street" class="form-select">
                                    <option value="0"></option>
                                    <?php
                                      foreach ($street_opt as $option) {
                                        echo "<option value='$option[0]'>$option[1]</option>";
                                      }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="barangay">Barangay</label>
                                <select name="brgy" id="barangay" class="form-select">
                                    <option value="0"></option>
                                    <?php
                                      foreach ($brgy_opt as $option) {
                                        echo "<option value='$option[0]'>$option[1]</option>";
                                      }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="municipality">Municipality</label>
                                <input type="text" name="municipal" class="form-control" readonly value="QUEZON">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="contact">Contact Number</label>
                                <input type="tel" name="contact" maxlength="11" class="form-control" id="contact"
                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" name="email" class="form-control" id="email">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="vaxStat">Vaccine Status</label>
                                <select name="vaccination" id="vaxStat" class="form-select">
                                  <option value="0"></option>
                                    <?php
                                      foreach ($vaccine as $option) {
                                        echo "<option value='$option[0]'>$option[1]</option>";
                                      }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- Buttons -->
                    <button type="submit" value="submit" class="btn btn-success me-2 mt-3">Register</button>
                    <button type="button" class="btn btn-danger mt-3"
                        onclick="location.href='../index.php'">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>