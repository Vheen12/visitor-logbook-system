-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 08:24 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `adminID` int(11) NOT NULL,
  `adminUsername` varchar(50) NOT NULL,
  `adminPassword` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`adminID`, `adminUsername`, `adminPassword`, `created_at`) VALUES
(14, 'admin', '$2y$10$BsLoCDnugE6wTrJX7jDvhOKNI5wW3WvPOyK.m4fZG.eFrgUpWe.c2', '2022-06-12 21:14:08');

-- --------------------------------------------------------

--
-- Table structure for table `brgy_address`
--

CREATE TABLE `brgy_address` (
  `brgyID` int(11) NOT NULL,
  `barangay` varchar(50) NOT NULL,
  `municipal_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brgy_address`
--

INSERT INTO `brgy_address` (`brgyID`, `barangay`, `municipal_ID`) VALUES
(1, 'ABUT', 20),
(2, 'ALUNAN', 20),
(3, 'ARELLANO', 20),
(4, 'AURORA', 20),
(5, 'BARUCBOC', 20),
(6, 'CALLANGIGAN', 20),
(7, 'DUMMON', 20),
(8, 'ESTRADA', 20),
(9, 'LEPANTO', 20),
(10, 'MANGGA', 20),
(11, 'MINAGBAG', 20),
(12, 'SAMONTE', 20),
(13, 'SAN JUAN', 20),
(14, 'SANTOS', 20),
(15, 'TUROD', 20);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `deptID` int(11) NOT NULL,
  `deptName` varchar(50) NOT NULL,
  `deptHead` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`deptID`, `deptName`, `deptHead`) VALUES
(2, 'Office of the Municipal Mayor', 'Hon. Jimmy S. Gamazon Jr.');

-- --------------------------------------------------------

--
-- Table structure for table `municipal_address`
--

CREATE TABLE `municipal_address` (
  `municipal_ID` int(11) NOT NULL,
  `municipality` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL DEFAULT 'ISABELA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `municipal_address`
--

INSERT INTO `municipal_address` (`municipal_ID`, `municipality`, `province`) VALUES
(1, 'ALICIA', 'ISABELA'),
(2, 'ANGADANAN', 'ISABELA'),
(3, 'AURORA', 'ISABELA'),
(4, 'BENITO SOLIVEN', 'ISABELA'),
(5, 'BURGOS', 'ISABELA'),
(6, 'CABAGAN', 'ISABELA'),
(7, 'CABATUAN', 'ISABELA'),
(8, 'CORDON', 'ISABELA'),
(9, 'DELFIN ALBANO', 'ISABELA'),
(10, 'DINAPIGUE', 'ISABELA'),
(11, 'DIVILACAN', 'ISABELA'),
(12, 'ECHAGUE', 'ISABELA'),
(13, 'GAMU', 'ISABELA'),
(14, 'JONES', 'ISABELA'),
(15, 'LUNA', 'ISABELA'),
(16, 'MACONACON', 'ISABELA'),
(17, 'MALLIG', 'ISABELA'),
(18, 'NAGUILIAN', 'ISABELA'),
(19, 'PALANAN', 'ISABELA'),
(20, 'QUEZON', 'ISABELA'),
(21, 'QUIRINO', 'ISABELA'),
(22, 'RAMON', 'ISABELA'),
(23, 'REINA MERCEDES', 'ISABELA'),
(24, 'ROXAS', 'ISABELA'),
(25, 'SAN AGUSTIN', 'ISABELA'),
(26, 'SAN GUILLERMO', 'ISABELA'),
(27, 'SAN ISIDRO', 'ISABELA'),
(28, 'SAN MANUEL', 'ISABELA'),
(29, 'SAN MARIANO', 'ISABELA'),
(30, 'SAN MATEO', 'ISABELA'),
(31, 'SAN PABLO', 'ISABELA'),
(32, 'SANTA MARIA', 'ISABELA'),
(33, 'SANTO TOMAS', 'ISABELA'),
(34, 'TUMAUINI', 'ISABELA');

-- --------------------------------------------------------

--
-- Table structure for table `purok_address`
--

CREATE TABLE `purok_address` (
  `purokID` int(11) NOT NULL,
  `purok` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purok_address`
--

INSERT INTO `purok_address` (`purokID`, `purok`) VALUES
(1, 'PUROK 1'),
(2, 'PUROK 2'),
(3, 'PUROK 3'),
(4, 'PUROK 4'),
(5, 'PUROK 5'),
(6, 'PUROK 6'),
(7, 'PUROK 7');

-- --------------------------------------------------------

--
-- Table structure for table `vaccine_stat`
--

CREATE TABLE `vaccine_stat` (
  `ID` int(11) NOT NULL,
  `vax_stat` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vaccine_stat`
--

INSERT INTO `vaccine_stat` (`ID`, `vax_stat`) VALUES
(1, 'UNVACCINATED'),
(2, 'FIRST DOSE ONLY'),
(3, 'FULLY VACCINATED'),
(4, 'FULLY VACCINATED WITH BOOSTER');

-- --------------------------------------------------------

--
-- Table structure for table `visiting_details`
--

CREATE TABLE `visiting_details` (
  `ID` int(11) NOT NULL,
  `visitor_ID` varchar(255) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `timeIn` time NOT NULL DEFAULT current_timestamp(),
  `dateIn` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visiting_details`
--

INSERT INTO `visiting_details` (`ID`, `visitor_ID`, `purpose`, `dept`, `timeIn`, `dateIn`) VALUES
(133, 'BARCELLANO, EMERSON, FRANCISCO', 'visit', 'Office of the Municipal Mayor', '11:07:02', '2022-06-13'),
(135, 'COLLADO, ARVIN, MONTILLA', 'visit', 'Office of the Municipal Mayor', '14:46:34', '2022-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_information`
--

CREATE TABLE `visitor_information` (
  `ID` int(11) NOT NULL,
  `visitor_ID` varchar(255) NOT NULL,
  `visitor_name` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `homeAddress` varchar(100) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `vaccineStat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitor_information`
--

INSERT INTO `visitor_information` (`ID`, `visitor_ID`, `visitor_name`, `birthdate`, `age`, `gender`, `homeAddress`, `contact`, `email`, `vaccineStat`) VALUES
(26, '6299a3f78a89c', 'COLLADO, ARVIN, MONTILLA', '1999-12-01', 22, 'male', 'PUROK 3, SAMONTE, QUEZON, ISABELA', '09666303638', 'arvincollado52@gmail.com', 'FULLY VACCINATED WITH BOOSTER'),
(27, '6299a638a0cdf', 'BARCELLANO,    EMERSON,    FRANCISCO   ', '1998-12-03', 23, 'male', 'PUROK 5, SAMONTE, QUEZON, ISABELA', '09683820079', 'emersonbarcellano4@gmail.com', 'FULLY VACCINATED'),
(45, '62a4229ef37cd', 'MONTILLA,  BLOSSOM,  ARES  ', '2005-07-04', 16, 'female', 'PUROK 3, SAMONTE, QUEZON, ISABELA', '', '', 'FULLY VACCINATED'),
(49, '62a6af1f1a5cc', 'BAUTISTA,  JASMINE,  GALANG  ', '1998-06-20', 23, 'female', 'PUROK 1, ABUT, QUEZON, ISABELA', '09754106468', 'jbautista081316@gmail.com', 'FULLY VACCINATED WITH BOOSTER'),
(50, '62a6dbad3a6fd', 'SAGAANG,  AXEL,  ANNAWAY  ', '1999-10-04', 22, 'male', 'PUROK 6, ARELLANO, QUEZON, ISABELA', '', '', 'FULLY VACCINATED');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`adminID`),
  ADD UNIQUE KEY `adminUsername` (`adminUsername`);

--
-- Indexes for table `brgy_address`
--
ALTER TABLE `brgy_address`
  ADD PRIMARY KEY (`brgyID`),
  ADD UNIQUE KEY `barangay` (`barangay`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`deptID`),
  ADD UNIQUE KEY `deptName` (`deptName`);

--
-- Indexes for table `municipal_address`
--
ALTER TABLE `municipal_address`
  ADD PRIMARY KEY (`municipal_ID`),
  ADD UNIQUE KEY `municipality` (`municipality`);

--
-- Indexes for table `purok_address`
--
ALTER TABLE `purok_address`
  ADD PRIMARY KEY (`purokID`);

--
-- Indexes for table `vaccine_stat`
--
ALTER TABLE `vaccine_stat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `visiting_details`
--
ALTER TABLE `visiting_details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `visitor_information`
--
ALTER TABLE `visitor_information`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `visitor_ID` (`visitor_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `brgy_address`
--
ALTER TABLE `brgy_address`
  MODIFY `brgyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `deptID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `municipal_address`
--
ALTER TABLE `municipal_address`
  MODIFY `municipal_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `purok_address`
--
ALTER TABLE `purok_address`
  MODIFY `purokID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vaccine_stat`
--
ALTER TABLE `vaccine_stat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `visiting_details`
--
ALTER TABLE `visiting_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `visitor_information`
--
ALTER TABLE `visitor_information`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
